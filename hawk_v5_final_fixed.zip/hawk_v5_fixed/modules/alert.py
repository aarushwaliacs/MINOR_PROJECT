"""Project Hawk v3 – Alert Module"""
import cv2, os, time, smtplib, logging, threading
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
from typing import List, Optional
import numpy as np

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s", datefmt="%H:%M:%S")
logger = logging.getLogger("HAWK")

class AlertManager:
    def __init__(self, save_dir="detected_frames", cooldown_sec=10.0,
                 email_sender=None, email_password=None, email_recipient=None,
                 smtp_host="smtp.gmail.com", smtp_port=587):
        self.save_dir = save_dir
        self.cooldown_sec = cooldown_sec
        self.email_cfg = (email_sender, email_password, email_recipient, smtp_host, smtp_port) if email_sender else None
        self._last: dict = {}
        self._lock = threading.Lock()
        self._total_alerts = 0
        os.makedirs(save_dir, exist_ok=True)

    def process(self, frame, detections, camera_id="CAM-01"):
        fired = []
        HIGH_RISK = {"knife","gun","scissors"}
        for det in detections:
            key = f"{camera_id}_{det.label}"
            with self._lock:
                if time.time()-self._last.get(key,0) < self.cooldown_sec: continue
                self._last[key] = time.time()
            ts  = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            msg = f"ALERT | {camera_id} | {det.label.upper()} | {det.confidence:.0%} | {ts}"
            if det.label.lower() in HIGH_RISK: logger.warning(msg)
            else: logger.info(msg)
            path = self._save(frame, det.label, ts)
            if self.email_cfg: threading.Thread(target=self._email, args=(msg,path,det), daemon=True).start()
            fired.append(msg)
            self._total_alerts += 1
        return fired

    def _save(self, frame, label, ts):
        fname = ts.replace(":"," - ").replace(" ","_") + f"_{label}.jpg"
        path  = os.path.join(self.save_dir, fname)
        cv2.imwrite(path, frame, [cv2.IMWRITE_JPEG_QUALITY,85])
        return path

    def _email(self, message, frame_path, det):
        sender,pwd,recipient,host,port = self.email_cfg
        try:
            msg = MIMEMultipart()
            msg["Subject"] = f"[HAWK] {det.label.upper()} Detected"
            msg["From"] = sender; msg["To"] = recipient
            msg.attach(MIMEText(message,"plain"))
            if os.path.exists(frame_path):
                with open(frame_path,"rb") as f: msg.attach(MIMEImage(f.read()))
            with smtplib.SMTP(host,port) as s: s.starttls(); s.login(sender,pwd); s.sendmail(sender,recipient,msg.as_string())
        except Exception as e: logger.error(f"Email failed: {e}")

    @property
    def total_alerts(self): return self._total_alerts
