"""Project Hawk v3 – Detection Module"""
import cv2, numpy as np, time
from dataclasses import dataclass, field
from typing import List, Tuple, Optional

@dataclass
class Detection:
    label: str
    confidence: float
    bbox: Tuple[int,int,int,int]
    center: Tuple[int,int] = field(init=False)
    timestamp: float = field(default_factory=time.time)
    track_id: int = 0

    def __post_init__(self):
        x,y,w,h = self.bbox
        self.center = (x+w//2, y+h//2)

    def to_dict(self):
        x,y,w,h = self.bbox
        return {"label":self.label,"confidence":round(self.confidence,3),
                "bbox":{"x":x,"y":y,"w":w,"h":h},
                "center":{"x":self.center[0],"y":self.center[1]},
                "timestamp":self.timestamp,"track_id":self.track_id}

class YOLODetector:
    HIGH_RISK = {"knife","scissors","gun","person","backpack","handbag","cell phone"}
    def __init__(self, model_name="yolov8n.pt", confidence=0.45, target_classes=None):
        self.confidence = confidence
        self.target_classes = target_classes
        self.model = None
        self._track_id = 0
        try:
            from ultralytics import YOLO
            self.model = YOLO(model_name)
            print(f"[HAWK] YOLOv8 '{model_name}' loaded.")
        except Exception as e:
            print(f"[HAWK] YOLO unavailable: {e} – using contour fallback.")

    def available(self): return self.model is not None

    def detect(self, frame) -> List[Detection]:
        if not self.available(): return []
        results = self.model.track(frame, conf=self.confidence, persist=True, verbose=False)[0]
        detections = []
        for box in results.boxes:
            cls_id = int(box.cls[0])
            label  = results.names[cls_id]
            if self.target_classes and label not in self.target_classes: continue
            conf = float(box.conf[0])
            x1,y1,x2,y2 = map(int, box.xyxy[0])
            tid = int(box.id[0]) if box.id is not None else 0
            detections.append(Detection(label=label, confidence=conf, bbox=(x1,y1,x2-x1,y2-y1), track_id=tid))
        return detections

class ContourDetector:
    def __init__(self, min_area=1500):
        self.min_area = min_area
    def detect(self, mask) -> List[Detection]:
        contours,_ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        dets = []
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area < self.min_area: continue
            x,y,w,h = cv2.boundingRect(cnt)
            dets.append(Detection(label="motion", confidence=min(1.0, area/50000), bbox=(x,y,w,h)))
        return dets

class HawkDetector:
    def __init__(self, yolo_model="yolov8n.pt", confidence=0.45, min_area=1500, target_classes=None):
        self.yolo    = YOLODetector(yolo_model, confidence, target_classes)
        self.contour = ContourDetector(min_area)

    def detect(self, frame, mask):
        if self.yolo.available():
            return self.yolo.detect(frame), "yolo"
        return self.contour.detect(mask), "contour"

    @staticmethod
    def annotate(frame, detections, strategy):
        annotated = frame.copy()
        COLORS = {"person":(0,80,255),"motion":(0,200,100),"knife":(0,0,255),"default":(0,180,220)}
        for det in detections:
            x,y,w,h = det.bbox
            color = COLORS.get(det.label, COLORS["default"])
            cv2.rectangle(annotated,(x,y),(x+w,y+h),color,2)
            label_text = f"{det.label} {det.confidence:.0%}"
            if det.track_id: label_text += f" #{det.track_id}"
            (tw,th),_ = cv2.getTextSize(label_text,cv2.FONT_HERSHEY_SIMPLEX,0.5,1)
            cv2.rectangle(annotated,(x,y-th-8),(x+tw+4,y),color,-1)
            cv2.putText(annotated,label_text,(x+2,y-4),cv2.FONT_HERSHEY_SIMPLEX,0.5,(255,255,255),1,cv2.LINE_AA)
        return annotated
