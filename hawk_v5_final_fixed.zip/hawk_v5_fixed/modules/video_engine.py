"""Project Hawk v5 – Robust Video Engine
Fixes:
  - Never exits on a dropped frame (reconnect loop instead of break)
  - Proper RTSP/HTTP/DroidCam URL handling with backend hints
  - Connection timeout via CAP_PROP_OPEN_TIMEOUT_MSEC
  - Exponential backoff reconnection (max 10s)
  - Thread-safe frame buffer with age tracking
  - Stale-frame detection: marks camera offline if no new frame for >5s
  - Heatmap, zone processing, recording all preserved
"""
import cv2, time, threading, os, numpy as np
from typing import Optional, List
from datetime import datetime
from modules.preprocessing import Preprocessor
from modules.detection import HawkDetector
from modules.alert import AlertManager
from modules.zone_manager import ZoneManager


# ── URL source helpers ────────────────────────────────────────────

def _is_url(source) -> bool:
    if isinstance(source, str):
        s = source.lower()
        return s.startswith(("http://", "https://", "rtsp://", "rtsps://", "rtmp://"))
    return False

def _open_capture(source) -> Optional[cv2.VideoCapture]:
    """
    Open a VideoCapture with sensible settings.
    For HTTP/RTSP/DroidCam URLs we set extra backend hints.
    Returns None if the source cannot be opened.
    """
    if _is_url(source):
        src_str = str(source)
        # DroidCam WiFi streams over HTTP: use FFMPEG backend directly
        # This bypasses the GStreamer pipeline that often fails on HTTP MJPEG
        if src_str.lower().startswith("http"):
            cap = cv2.VideoCapture(src_str, cv2.CAP_FFMPEG)
        else:
            # RTSP — use FFMPEG, prefer TCP transport (more reliable than UDP)
            os.environ.setdefault("OPENCV_FFMPEG_CAPTURE_OPTIONS", "rtsp_transport;tcp")
            cap = cv2.VideoCapture(src_str, cv2.CAP_FFMPEG)
    else:
        # Integer device index
        cap = cv2.VideoCapture(int(source) if not isinstance(source, int) else source)

    if not cap.isOpened():
        return None

    # Reduce internal buffer so we always get the latest frame, not stale ones
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    # For URL sources, set a read timeout (OpenCV 4.5+)
    try:
        cap.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 5000)
        cap.set(cv2.CAP_PROP_READ_TIMEOUT_MSEC, 4000)
    except Exception:
        pass  # older OpenCV versions don't have these props

    return cap


class VideoEngine:
    # Max time (seconds) without a new frame before we consider camera offline
    STALE_TIMEOUT = 5.0
    # Reconnect backoff: starts at 2s, doubles up to MAX_BACKOFF
    INITIAL_BACKOFF = 2.0
    MAX_BACKOFF = 10.0

    def __init__(self, source=0, camera_id="CAM-01", skip_frames=2,
                 yolo_model="yolov8n.pt", alert_manager=None,
                 zone_manager=None, show_heatmap=False):
        self.source        = source
        self.camera_id     = camera_id
        self.skip_frames   = skip_frames
        self.alert_manager = alert_manager
        self.zone_manager  = zone_manager
        self.show_heatmap  = show_heatmap
        self.preprocessor  = Preprocessor(target_width=640)
        self.detector      = HawkDetector(yolo_model=yolo_model)

        self._frame_lock      = threading.Lock()
        self._latest_frame: Optional[np.ndarray] = None
        self._last_frame_time: float = 0.0   # epoch time of last successful frame

        self._running    = False
        self._recording  = False
        self._video_writer: Optional[cv2.VideoWriter] = None
        self._email_callback = None   # set by app.py after init

        self.stats = {
            "fps": 0.0,
            "detections_total": 0,
            "alerts_total": 0,
            "strategy": "contour",
            "zone_alerts": 0,
            "recording": False,
            "reconnects": 0,
            "source": str(source),
        }
        self._recent_detections: List[dict] = []
        self._zone_alerts: List[dict]       = []
        self._fps_history: List[float]      = []

    def _save_alert_snap(self, frame):
        """Save current frame as snapshot for email attachment."""
        try:
            os.makedirs("detected_frames", exist_ok=True)
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            path = os.path.join("detected_frames", f"alert_{self.camera_id}_{ts}.jpg")
            cv2.imwrite(path, frame, [cv2.IMWRITE_JPEG_QUALITY, 85])
            return path
        except Exception:
            return None

    # ── Public API ──────────────────────────────────────────────

    def start(self):
        self._running = True
        threading.Thread(target=self._run, daemon=True, name=f"hawk-{self.camera_id}").start()

    def stop(self):
        self._running = False

    def get_frame(self) -> Optional[np.ndarray]:
        """Return the latest frame, or None if offline/stale."""
        with self._frame_lock:
            if self._latest_frame is None:
                return None
            # Consider camera offline if no new frame for STALE_TIMEOUT seconds
            if self._last_frame_time and (time.time() - self._last_frame_time) > self.STALE_TIMEOUT:
                return None
            return self._latest_frame.copy()

    def get_stats(self)    -> dict: return dict(self.stats)
    def get_recent_detections(self, n=20) -> list: return self._recent_detections[-n:]
    def get_zone_alerts(self, n=30)       -> list: return self._zone_alerts[-n:]
    def set_heatmap(self, v: bool):  self.show_heatmap = v

    def start_recording(self, clip_dir="clips"):
        if self._recording:
            return  # already recording
        os.makedirs(clip_dir, exist_ok=True)
        ts   = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(clip_dir, f"{self.camera_id}_{ts}.avi")
        self._video_writer = cv2.VideoWriter(
            path, cv2.VideoWriter_fourcc(*"XVID"), 15, (640, 360)
        )
        self._recording = True
        self.stats["recording"] = True
        threading.Timer(15.0, self.stop_recording).start()
        print(f"[HAWK] ⏺ Recording → {path}")

    def stop_recording(self):
        self._recording = False
        self.stats["recording"] = False
        if self._video_writer:
            self._video_writer.release()
            self._video_writer = None

    # ── Internal loop with reconnection ─────────────────────────

    def _run(self):
        """
        Outer reconnect loop. If the inner capture loop exits for any reason
        (dropped frames, connection lost, etc.) we wait with backoff and retry.
        We only stop when self._running is False.
        """
        backoff = self.INITIAL_BACKOFF
        is_url  = _is_url(self.source)

        while self._running:
            print(f"[HAWK] Connecting to {self.source} ...")
            cap = _open_capture(self.source)

            if cap is None:
                print(f"[HAWK] ✗ Cannot open: {self.source}  — retry in {backoff:.0f}s")
                self._wait_or_stop(backoff)
                backoff = min(backoff * 2, self.MAX_BACKOFF)
                self.stats["reconnects"] += 1
                continue

            print(f"[HAWK] ✓ Connected: {self.source}")
            backoff = self.INITIAL_BACKOFF  # reset on success

            # Inner read loop
            exited_cleanly = self._capture_loop(cap)
            cap.release()

            if not self._running:
                break  # intentional stop

            if exited_cleanly:
                # Clean EOF (local file finished), don't reconnect
                print(f"[HAWK] Stream ended: {self.source}")
                break
            else:
                # Lost connection — reconnect
                self.stats["reconnects"] += 1
                print(f"[HAWK] ⚠ Stream lost: {self.source}  — retry in {backoff:.0f}s")
                self._wait_or_stop(backoff)
                backoff = min(backoff * 2, self.MAX_BACKOFF)

        if self._video_writer:
            self._video_writer.release()
        print(f"[HAWK] Engine stopped: {self.camera_id}")

    def _wait_or_stop(self, seconds: float):
        """Sleep in small increments so we can respond to stop() quickly."""
        deadline = time.time() + seconds
        while self._running and time.time() < deadline:
            time.sleep(0.25)

    def _capture_loop(self, cap: cv2.VideoCapture) -> bool:
        """
        Inner frame-read loop.
        Returns True  = clean end-of-stream (local file)
        Returns False = error / connection lost (should reconnect)
        """
        is_url       = _is_url(self.source)
        frame_count  = 0
        fps_count    = 0
        fps_timer    = time.time()
        consecutive_fails = 0
        MAX_FAILS = 10  # tolerate up to 10 consecutive bad reads before reconnecting

        while self._running:
            ret, frame = cap.read()

            if not ret or frame is None:
                consecutive_fails += 1
                if consecutive_fails >= MAX_FAILS:
                    # Too many failures in a row — signal reconnect
                    return False
                # Single bad frame is common on streams — skip and keep going
                if is_url:
                    time.sleep(0.05)
                continue

            # Good frame — reset fail counter
            consecutive_fails = 0
            frame_count  += 1
            fps_count    += 1

            now = time.time()
            self._last_frame_time = now

            elapsed = now - fps_timer
            if elapsed >= 1.0:
                fps = round(fps_count / elapsed, 1)
                self.stats["fps"] = fps
                self._fps_history.append(fps)
                if len(self._fps_history) > 60:
                    self._fps_history = self._fps_history[-60:]
                fps_count = 0
                fps_timer = now

            # Skip frames for performance (but always update the raw latest)
            if frame_count % self.skip_frames != 0:
                # Still update frame so the feed doesn't freeze
                with self._frame_lock:
                    self._latest_frame = frame
                continue

            # ── Process frame ──
            resized, mask = self.preprocessor.run(frame)
            detections, strategy = self.detector.detect(resized, mask)
            self.stats["strategy"] = strategy

            if detections:
                self.stats["detections_total"] += len(detections)
                for det in detections:
                    self._recent_detections.append(det.to_dict())
                if len(self._recent_detections) > 300:
                    self._recent_detections = self._recent_detections[-300:]
                if self.alert_manager:
                    fired = self.alert_manager.process(resized, detections, self.camera_id)
                    self.stats["alerts_total"] += len(fired)
                    if fired and not self._recording:
                        self.start_recording()

            if self.show_heatmap and self.zone_manager:
                resized = self.zone_manager.generate_heatmap(resized, detections)

            zone_alerts = []   # always defined
            if self.zone_manager:
                resized, zone_alerts = self.zone_manager.process_frame(resized, detections)
                if zone_alerts:
                    self._zone_alerts.extend(zone_alerts)
                    if len(self._zone_alerts) > 300:
                        self._zone_alerts = self._zone_alerts[-300:]
                    self.stats["zone_alerts"] += len(zone_alerts)
                    if not self._recording:
                        self.start_recording()

            annotated = self.detector.annotate(resized, detections, strategy)
            self._add_overlay(annotated)

            # Fire email AFTER annotated frame is ready
            if self.zone_manager and zone_alerts and self._email_callback:
                for za in zone_alerts:
                    snap = self._save_alert_snap(annotated)
                    self._email_callback(
                        za.get("type", "Zone Alert"),
                        za.get("zone", ""),
                        za.get("msg", ""),
                        snap
                    )

            if self._recording and self._video_writer:
                self._video_writer.write(cv2.resize(annotated, (640, 360)))

            with self._frame_lock:
                self._latest_frame = annotated

        # self._running became False — clean exit
        return True

    # ── Frame overlay ─────────────────────────────────────────────

    def _add_overlay(self, frame):
        ts  = time.strftime("%Y-%m-%d  %H:%M:%S")
        fps = self.stats["fps"]
        h, w = frame.shape[:2]
        ov = frame.copy()
        cv2.rectangle(ov, (0, 0), (w, 30), (10, 12, 18), -1)
        cv2.addWeighted(ov, 0.65, frame, 0.35, 0, frame)
        cv2.putText(frame, ts, (8, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.48, (140, 165, 190), 1, cv2.LINE_AA)
        cv2.putText(frame, f"FPS:{fps}", (w - 82, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.48, (0, 220, 110), 1, cv2.LINE_AA)
        cv2.putText(frame, self.camera_id, (w // 2 - 30, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (190, 200, 215), 1, cv2.LINE_AA)
        if self._recording:
            cv2.circle(frame, (w - 18, h - 18), 7, (0, 60, 255), -1)
            cv2.putText(frame, "REC", (w - 52, h - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 80, 255), 1, cv2.LINE_AA)
