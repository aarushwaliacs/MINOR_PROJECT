"""Project Hawk v3 – Preprocessing Module"""
import cv2, numpy as np

class Preprocessor:
    def __init__(self, target_width=640, blur_kernel=5, morph_kernel=3):
        self.target_width = target_width
        self.blur_kernel = blur_kernel
        self.kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (morph_kernel, morph_kernel))
        self.bg_subtractor = cv2.createBackgroundSubtractorMOG2(history=500, varThreshold=50, detectShadows=True)

    def resize(self, frame):
        h, w = frame.shape[:2]
        scale = self.target_width / w
        return cv2.resize(frame, (self.target_width, int(h * scale)), interpolation=cv2.INTER_AREA)

    def run(self, frame):
        resized  = self.resize(frame)
        gray     = cv2.cvtColor(resized, cv2.COLOR_BGR2GRAY)
        blurred  = cv2.GaussianBlur(gray, (self.blur_kernel if self.blur_kernel%2==1 else self.blur_kernel+1, self.blur_kernel if self.blur_kernel%2==1 else self.blur_kernel+1), 0)
        fg_mask  = self.bg_subtractor.apply(blurred)
        _, mask  = cv2.threshold(fg_mask, 200, 255, cv2.THRESH_BINARY)
        opened   = cv2.morphologyEx(mask, cv2.MORPH_OPEN,  self.kernel)
        closed   = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, self.kernel)
        dilated  = cv2.dilate(closed, self.kernel, iterations=2)
        return resized, dilated
