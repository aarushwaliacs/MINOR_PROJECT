"""Project Hawk v3 – Zone Manager (Full Intelligence Engine)"""
import cv2, json, time, os, uuid, numpy as np
from dataclasses import dataclass, field, asdict
from typing import List, Tuple, Dict, Optional
from datetime import datetime

@dataclass
class ZoneRule:
    no_entry: bool = False
    restricted_after: Optional[str] = None
    restricted_before: Optional[str] = None
    max_duration_sec: int = 0
    high_crowd_alert: bool = True
    def to_dict(self): return asdict(self)
    @classmethod
    def from_dict(cls, d):
        fields = {k:v for k,v in d.items() if k in cls.__dataclass_fields__}
        return cls(**fields)

@dataclass
class Zone:
    id: str
    name: str
    points: List[List[int]]
    capacity: int = 5
    risk_level: str = "Medium"
    rules: ZoneRule = field(default_factory=ZoneRule)
    color: List[int] = field(default_factory=lambda:[0,200,100])
    current_count: int = field(default=0, repr=False)
    alert_active:  bool = field(default=False, repr=False)
    status: str = field(default="safe", repr=False)

    def to_dict(self):
        return {"id":self.id,"name":self.name,"points":self.points,
                "capacity":self.capacity,"risk_level":self.risk_level,
                "rules":self.rules.to_dict(),"color":self.color}

    @classmethod
    def from_dict(cls, d):
        return cls(id=d["id"], name=d["name"], points=d["points"],
                   capacity=d.get("capacity",5), risk_level=d.get("risk_level","Medium"),
                   rules=ZoneRule.from_dict(d.get("rules",{})), color=d.get("color",[0,200,100]))

    def np_points(self): return np.array(self.points, dtype=np.int32)

    def contains_point(self, x, y):
        if len(self.points) < 3: return False
        return cv2.pointPolygonTest(self.np_points(),(float(x),float(y)),False) >= 0

    def get_color(self):
        if self.status=="critical": return (0,0,255)
        if self.status=="warning":  return (0,140,255)
        return (0,200,100)

class LoiteringTracker:
    def __init__(self):
        self._entries: Dict[str, Dict[str,float]] = {}

    def update(self, zone_id, centers):
        if zone_id not in self._entries: self._entries[zone_id] = {}
        now = time.time()
        active = set()
        for cx,cy in centers:
            key = f"{cx//30}_{cy//30}"
            active.add(key)
            if key not in self._entries[zone_id]:
                self._entries[zone_id][key] = now
        for k in list(self._entries[zone_id]):
            if k not in active: del self._entries[zone_id][k]

    def max_duration(self, zone_id):
        entries = self._entries.get(zone_id,{})
        if not entries: return 0.0
        return max(time.time()-t for t in entries.values())

class AbnormalDetector:
    """Detects rapid movement and unusual patterns via optical flow heuristics."""
    def __init__(self):
        self._prev_gray: Dict[str,np.ndarray] = {}
        self._vel_history: Dict[str,List[float]] = {}

    def analyze(self, zone_id, frame_gray, mask_pts):
        if zone_id not in self._prev_gray:
            self._prev_gray[zone_id] = frame_gray
            return False, 0.0
        prev = self._prev_gray[zone_id]
        try:
            flow = cv2.calcOpticalFlowFarneback(prev, frame_gray, None, 0.5,3,15,3,5,1.2,0)
            mag, _ = cv2.cartToPolar(flow[...,0], flow[...,1])
            mean_mag = float(np.mean(mag))
            if zone_id not in self._vel_history: self._vel_history[zone_id] = []
            self._vel_history[zone_id].append(mean_mag)
            if len(self._vel_history[zone_id]) > 30:
                self._vel_history[zone_id] = self._vel_history[zone_id][-30:]
            baseline = np.mean(self._vel_history[zone_id][:-1]) if len(self._vel_history[zone_id])>1 else mean_mag
            abnormal = mean_mag > baseline * 3.0 and mean_mag > 2.0
        except:
            abnormal, mean_mag = False, 0.0
        self._prev_gray[zone_id] = frame_gray
        return abnormal, mean_mag

class ZoneManager:
    DB_PATH  = "data/zones.json"
    LOG_PATH = "data/events.json"

    def __init__(self):
        self.zones: Dict[str,Zone] = {}
        self._loitering  = LoiteringTracker()
        self._abnormal   = AbnormalDetector()
        self._event_log: List[dict] = []
        self._alert_counts: Dict[str,int] = {}
        self._last_alert_time: Dict[str,float] = {}
        os.makedirs("data", exist_ok=True)
        self._load()

    def _load(self):
        if os.path.exists(self.DB_PATH):
            try:
                with open(self.DB_PATH) as f: data = json.load(f)
                for zd in data:
                    z = Zone.from_dict(zd)
                    self.zones[z.id] = z
                print(f"[HAWK] {len(self.zones)} zones loaded.")
            except Exception as e: print(f"[HAWK] Zone load error: {e}")

    def save(self):
        with open(self.DB_PATH,"w") as f:
            json.dump([z.to_dict() for z in self.zones.values()],f,indent=2)

    def _log_event(self, zone, event_type, detail, severity="medium"):
        entry = {"timestamp":datetime.now().isoformat(),"zone_id":zone.id,
                 "zone_name":zone.name,"event":event_type,"detail":detail,
                 "count":zone.current_count,"capacity":zone.capacity,"severity":severity}
        self._event_log.append(entry)
        if len(self._event_log)>1000: self._event_log=self._event_log[-1000:]
        try:
            existing = []
            if os.path.exists(self.LOG_PATH):
                with open(self.LOG_PATH) as f: existing=json.load(f)
            existing.append(entry)
            with open(self.LOG_PATH,"w") as f: json.dump(existing[-1000:],f,indent=2)
        except: pass

    def _cooldown_ok(self, key, seconds=8):
        now = time.time()
        if now - self._last_alert_time.get(key,0) >= seconds:
            self._last_alert_time[key] = now
            return True
        return False

    def add_zone(self, zone): self.zones[zone.id]=zone; self.save()
    def update_zone(self, zone_id, data):
        if zone_id not in self.zones: return False
        z = self.zones[zone_id]
        for k,v in data.items():
            if k=="rules": z.rules=ZoneRule.from_dict(v)
            elif hasattr(z,k) and k not in ("current_count","alert_active","status"): setattr(z,k,v)
        self.save(); return True
    def delete_zone(self, zone_id):
        if zone_id in self.zones: del self.zones[zone_id]; self.save(); return True
        return False

    def get_all(self):
        result=[]
        for z in self.zones.values():
            d=z.to_dict()
            d.update({"current_count":z.current_count,"status":z.status,"alert_active":z.alert_active})
            result.append(d)
        return result

    def process_frame(self, frame, detections):
        alerts = []
        now_str = datetime.now().strftime("%H:%M")
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        persons = [d for d in detections if d.label=="person"]

        for zone in self.zones.values():
            if len(zone.points)<3: continue
            in_zone, centers = [], []
            for p in persons:
                if zone.contains_point(*p.center):
                    in_zone.append(p); centers.append(p.center)
            zone.current_count = len(in_zone)
            self._loitering.update(zone.id, centers)

            # Abnormal movement
            mask_pts = zone.np_points()
            abnormal, vel = self._abnormal.analyze(zone.id, gray, mask_pts)

            # Status
            ratio = zone.current_count / max(zone.capacity,1)
            zone.status = "critical" if ratio>=1.0 else "warning" if ratio>=0.75 else "safe"
            zone.alert_active = False

            # Rules evaluation
            r = zone.rules
            key_base = f"{zone.id}"

            if zone.current_count > zone.capacity and self._cooldown_ok(f"{key_base}_crowd"):
                msg = {"type":"overcrowding","zone":zone.name,"msg":f"OVERCROWDED: {zone.name} — {zone.current_count}/{zone.capacity} people","severity":"critical"}
                alerts.append(msg); zone.alert_active=True
                self._log_event(zone,"overcrowding",msg["msg"],"critical")
                self._alert_counts[zone.id] = self._alert_counts.get(zone.id,0)+1

            if r.no_entry and zone.current_count>0 and self._cooldown_ok(f"{key_base}_noentry"):
                msg = {"type":"intrusion","zone":zone.name,"msg":f"INTRUSION: {zone.name} is NO-ENTRY — {zone.current_count} detected","severity":"critical"}
                alerts.append(msg); zone.alert_active=True
                self._log_event(zone,"intrusion",msg["msg"],"critical")

            if r.restricted_after and now_str>=r.restricted_after and zone.current_count>0 and self._cooldown_ok(f"{key_base}_time"):
                msg = {"type":"time_violation","zone":zone.name,"msg":f"TIME VIOLATION: {zone.name} restricted after {r.restricted_after}","severity":"high"}
                alerts.append(msg); zone.alert_active=True
                self._log_event(zone,"time_violation",msg["msg"],"high")

            if r.max_duration_sec>0 and self._loitering.max_duration(zone.id)>=r.max_duration_sec and self._cooldown_ok(f"{key_base}_loit"):
                dur = int(self._loitering.max_duration(zone.id))
                msg = {"type":"loitering","zone":zone.name,"msg":f"LOITERING: {zone.name} — person for {dur}s (limit {r.max_duration_sec}s)","severity":"high"}
                alerts.append(msg); zone.alert_active=True
                self._log_event(zone,"loitering",msg["msg"],"high")

            if abnormal and vel>3.0 and self._cooldown_ok(f"{key_base}_abnormal",15):
                msg = {"type":"abnormal","zone":zone.name,"msg":f"ABNORMAL MOVEMENT: {zone.name} — rapid activity detected","severity":"medium"}
                alerts.append(msg); zone.alert_active=True
                self._log_event(zone,"abnormal_movement",msg["msg"],"medium")

            self._draw_zone(frame, zone)

        return frame, alerts

    def _draw_zone(self, frame, zone):
        pts = zone.np_points()
        color = zone.get_color()
        alpha = 0.12 if zone.status=="safe" else 0.25

        overlay = frame.copy()
        cv2.fillPoly(overlay,[pts],color)
        cv2.addWeighted(overlay,alpha,frame,1-alpha,0,frame)

        thickness = 3 if zone.alert_active else 2
        cv2.polylines(frame,[pts],True,color,thickness,cv2.LINE_AA)

        if zone.status=="critical" and int(time.time()*3)%2==0:
            cv2.polylines(frame,[pts],True,(0,0,255),5,cv2.LINE_AA)

        cx = int(np.mean([p[0] for p in zone.points]))
        cy = int(np.mean([p[1] for p in zone.points]))

        (tw,th),_ = cv2.getTextSize(zone.name,cv2.FONT_HERSHEY_SIMPLEX,0.55,1)
        cv2.rectangle(frame,(cx-tw//2-8,cy-26),(cx+tw//2+8,cy+22),(8,12,20),-1)
        cv2.putText(frame,zone.name,(cx-tw//2,cy-10),cv2.FONT_HERSHEY_SIMPLEX,0.55,color,1,cv2.LINE_AA)
        count_col = (0,0,255) if zone.status=="critical" else (0,165,255) if zone.status=="warning" else (255,255,255)
        cv2.putText(frame,f"{zone.current_count}/{zone.capacity}",(cx-16,cy+16),cv2.FONT_HERSHEY_SIMPLEX,0.6,count_col,2,cv2.LINE_AA)

    def generate_heatmap(self, frame, detections):
        hm = np.zeros(frame.shape[:2],dtype=np.float32)
        for d in detections:
            if d.label=="person":
                cx,cy=d.center
                if 0<=cy<hm.shape[0] and 0<=cx<hm.shape[1]:
                    cv2.circle(hm,(cx,cy),70,1.0,-1)
        if hm.max()>0:
            hm=cv2.GaussianBlur(hm,(71,71),0)
            hm=(hm/hm.max()*255).astype(np.uint8)
            colored=cv2.applyColorMap(hm,cv2.COLORMAP_TURBO)
            mask=hm>15
            frame[mask]=cv2.addWeighted(frame,0.45,colored,0.55,0)[mask]
        return frame

    def get_stats(self):
        z=list(self.zones.values())
        return {"total":len(z),"safe":sum(1 for x in z if x.status=="safe"),
                "warning":sum(1 for x in z if x.status=="warning"),
                "critical":sum(1 for x in z if x.status=="critical"),
                "people":sum(x.current_count for x in z),
                "total_alerts":sum(self._alert_counts.values())}

    def get_event_log(self, n=50): return self._event_log[-n:]
    def get_alert_counts(self): return dict(self._alert_counts)
