/* ── Project Hawk v5 — Core JS ── */

/* ── API Helpers ── */
async function GET(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
}
async function POST(url, body = {}) {
  const r = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
}

/* ── Toast System ── */
const Toast = {
  _icons: { success: '✓', error: '✕', warning: '⚠', info: 'ℹ' },
  show(type, title, body = '', duration = 4000) {
    const container = document.getElementById('toast-container');
    if (!container) return;
    const t = document.createElement('div');
    t.className = `toast ${type}`;
    t.innerHTML = `
      <span class="toast-icon">${this._icons[type] || 'ℹ'}</span>
      <div class="toast-content">
        <div class="toast-title">${title}</div>
        ${body ? `<div class="toast-body">${body}</div>` : ''}
      </div>
      <button class="toast-close" onclick="Toast._remove(this.parentElement)">×</button>`;
    container.appendChild(t);
    if (duration > 0) setTimeout(() => this._remove(t), duration);
  },
  _remove(el) {
    if (!el || el.classList.contains('removing')) return;
    el.classList.add('removing');
    setTimeout(() => el.remove(), 280);
  },
  success: (t, b) => Toast.show('success', t, b),
  error:   (t, b) => Toast.show('error', t, b),
  warning: (t, b) => Toast.show('warning', t, b),
  info:    (t, b) => Toast.show('info', t, b),
};

/* ── Modal System ── */
function openModal(id) {
  const el = document.getElementById(id);
  if (el) { el.classList.add('open'); el.style.display = 'flex'; }
}
function closeModal(id) {
  const el = document.getElementById(id);
  if (el) { el.classList.remove('open'); el.style.display = 'none'; }
}
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-backdrop.open').forEach(m => {
      m.classList.remove('open'); m.style.display = 'none';
    });
    NotifPanel.close();
  }
});
document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-backdrop')) {
    e.target.classList.remove('open');
    e.target.style.display = 'none';
  }
});

/* ── Tab System ── */
function switchTab(btn, paneId) {
  const container = btn.closest('.card, .tab-container') || btn.parentElement.closest('div');
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('.tab-pane').forEach(p => {
    p.classList.toggle('active', p.id === paneId);
  });
}

/* ── Notification Panel ── */
const NotifPanel = {
  open() {
    document.getElementById('notif-panel')?.classList.add('open');
  },
  close() {
    document.getElementById('notif-panel')?.classList.remove('open');
  },
  toggle() {
    const panel = document.getElementById('notif-panel');
    if (!panel) return;
    panel.classList.contains('open') ? this.close() : this.open();
  },
  async load() {
    try {
      const notifs = await GET('/api/notifications?limit=30');
      this._render(notifs);
      const unread = notifs.filter(n => !n.read).length;
      const dot = document.getElementById('main-notif-dot');
      if (dot) { dot.classList.toggle('show', unread > 0); }
      const badge = document.getElementById('nav-alert-badge');
      if (badge) {
        badge.style.display = unread > 0 ? 'inline-block' : 'none';
        badge.textContent = unread > 9 ? '9+' : unread;
      }
    } catch {}
  },
  _render(notifs) {
    const list = document.getElementById('notif-list');
    if (!list) return;
    if (!notifs.length) {
      list.innerHTML = `<div class="empty-state" style="padding:32px;"><div class="empty-icon">🔔</div><div class="empty-title">All clear</div><div class="empty-desc">No notifications</div></div>`;
      return;
    }
    list.innerHTML = notifs.map(n => {
      const time = n.ts ? new Date(n.ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';
      return `<div class="notif-item ${n.read ? '' : 'unread'}" onclick="NotifPanel._markRead('${n.id}',this)">
        <div class="notif-level-dot ${n.level || 'info'}"></div>
        <div class="notif-body">
          <div class="notif-item-title">${n.title}</div>
          <div class="notif-item-body">${n.body}</div>
          <div class="notif-item-time">${time}</div>
        </div>
      </div>`;
    }).join('');
  },
  async _markRead(id, el) {
    try {
      await POST('/api/notifications/read', { id });
      el?.classList.remove('unread');
      this.load();
    } catch {}
  },
  async markAllRead() {
    try {
      await POST('/api/notifications/read', {});
      this.load();
    } catch {}
  },
  async clear() {
    try {
      await POST('/api/notifications/clear');
      this.load();
    } catch {}
  }
};

/* ── Clock ── */
function startClock() {
  const el = document.getElementById('topbar-clock');
  if (!el) return;
  function tick() {
    const now = new Date();
    const time = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const date = now.toLocaleDateString([], { month: 'short', day: 'numeric' });
    el.textContent = `${date}  ${time}`;
  }
  tick();
  setInterval(tick, 1000);
}

/* ── Active Nav ── */
function setActiveNav() {
  const path = window.location.pathname;
  document.querySelectorAll('.nav-item[data-href]').forEach(el => {
    el.classList.toggle('active', el.dataset.href === path);
  });
}

/* ── Format helpers ── */
function fmtNum(n) {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k';
  return String(n);
}
function fmtUptime(s) {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${sec}s`;
  return `${sec}s`;
}
function fmtTime(ts) {
  if (!ts) return '—';
  const d = new Date(ts.includes('T') ? ts : ts * 1000);
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
function fmtDateTime(ts) {
  if (!ts) return '—';
  const d = new Date(ts.includes('T') ? ts : ts * 1000);
  return d.toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

/* ── Demo mode badge ── */
async function checkDemoMode() {
  try {
    const s = await GET('/api/summary');
    const badge = document.getElementById('sb-demo');
    if (badge) badge.style.display = s.demo_mode ? 'inline-block' : 'none';
  } catch {}
}

/* ── Topbar notification button wiring ── */
document.addEventListener('DOMContentLoaded', () => {
  setActiveNav();
  startClock();
  NotifPanel.load();
  checkDemoMode();
  setInterval(() => NotifPanel.load(), 5000);

  document.querySelectorAll('[data-action="toggle-notif"]').forEach(btn => {
    btn.addEventListener('click', e => { e.stopPropagation(); NotifPanel.toggle(); });
  });
  document.addEventListener('click', e => {
    const panel = document.getElementById('notif-panel');
    if (panel && !panel.contains(e.target) && !e.target.closest('[data-action="toggle-notif"]')) {
      NotifPanel.close();
    }
  });
});
